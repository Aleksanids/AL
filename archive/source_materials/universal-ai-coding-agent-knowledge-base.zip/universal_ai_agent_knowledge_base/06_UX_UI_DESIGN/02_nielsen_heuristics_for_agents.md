# Nielsen heuristics для агента

## 10 проверок

1. Visibility of system status.
2. Match between system and real world.
3. User control and freedom.
4. Consistency and standards.
5. Error prevention.
6. Recognition rather than recall.
7. Flexibility and efficiency of use.
8. Aesthetic and minimalist design.
9. Help users recognize, diagnose, recover from errors.
10. Help and documentation.

## Agent output

UX reviewer должен указывать не только проблему, но и конкретный экран/компонент/сценарий.
